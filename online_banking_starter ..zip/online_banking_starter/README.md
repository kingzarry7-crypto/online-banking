# Online Banking Starter

A legitimate starter/demo banking web app with original branding and UI.
It is not connected to real banking rails or real money.

## Stack
- FastAPI + Python
- PostgreSQL
- SQLAlchemy
- JWT authentication
- Password hashing with Argon2
- Email OTP support
- Responsive HTML/CSS/JS frontend
- Admin endpoints

## 1. Create environment

Python 3.11+ is recommended.

```bash
python -m venv .venv
# macOS/Linux:
source .venv/bin/activate
# Windows:
.venv\Scripts\activate

pip install -r backend/requirements.txt
```

## 2. Start PostgreSQL

The easiest local method is Docker:

```bash
docker compose up -d db
```

Then copy `.env.example` to `.env`.

## 3. Run the API

```bash
uvicorn backend.main:app --reload
```

Open:
- http://127.0.0.1:8000
- API docs: http://127.0.0.1:8000/docs

The frontend is served by FastAPI, so you do not need a second server for local testing.

## Demo admin

Set these in `.env`:
ADMIN_EMAIL=admin@example.com
ADMIN_PASSWORD=change-this-password

Do not use these demo values in production.

## Production

For deployment, use:
- Render/Railway/Fly.io for the FastAPI service
- Managed PostgreSQL
- A real email provider for OTP
- HTTPS
- Strong random SECRET_KEY
- Proper domain and production CORS settings

Never connect this starter directly to a real bank account or payment rail without the required compliance, security review, and provider integration.
