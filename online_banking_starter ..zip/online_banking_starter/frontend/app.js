const $ = id => document.getElementById(id);
const tokenKey = "online_banking_token";

function show(id){
  ["login","register","verify","dashboard","transfer"].forEach(x => $(x)?.classList.add("hidden"));
  $(id)?.classList.remove("hidden");
  $("bottomNav").classList.toggle("hidden", !["dashboard","transfer"].includes(id));
  if(id === "dashboard") loadDashboard();
}

async function api(path, options={}){
  options.headers = {"Content-Type":"application/json", ...(options.headers||{})};
  const token = localStorage.getItem(tokenKey);
  if(token) options.headers.Authorization = `Bearer ${token}`;
  const res = await fetch(path, options);
  const data = await res.json().catch(()=>({}));
  if(!res.ok) throw new Error(data.detail || "Request failed");
  return data;
}

async function register(){
  try{
    const data = await api("/api/auth/register",{method:"POST",body:JSON.stringify({
      full_name:$("regName").value,
      email:$("regEmail").value,
      password:$("regPassword").value
    })});
    $("regMsg").textContent = data.message;
    $("otpEmail").value = $("regEmail").value;
    show("verify");
  }catch(e){$("regMsg").textContent=e.message}
}

async function verify(){
  try{
    const data = await api("/api/auth/verify",{method:"POST",body:JSON.stringify({
      email:$("otpEmail").value,code:$("otpCode").value
    })});
    $("otpMsg").textContent=data.message;
    show("login");
  }catch(e){$("otpMsg").textContent=e.message}
}

async function login(){
  try{
    const data = await api("/api/auth/login",{method:"POST",body:JSON.stringify({
      email:$("loginEmail").value,password:$("loginPassword").value
    })});
    localStorage.setItem(tokenKey,data.access_token);
    show("dashboard");
  }catch(e){$("loginMsg").textContent=e.message}
}

async function loadDashboard(){
  try{
    const me=await api("/api/me");
    $("welcome").textContent=`Welcome, ${me.full_name.split(" ")[0]}`;
    $("balance").textContent=`$${Number(me.balance).toLocaleString("en-US",{minimumFractionDigits:2})}`;
    $("accountNumber").textContent=`Account •••• ${me.account_number.slice(-4)}`;

    const txs=await api("/api/transactions");
    $("transactions").innerHTML=txs.length ? txs.map(x=>`
      <div class="tx">
        <div><b>${escapeHtml(x.description)}</b><small>${new Date(x.created_at).toLocaleString()}</small></div>
        <strong class="${x.type}">${x.type==="credit"?"+":"-"}$${Number(x.amount).toLocaleString("en-US",{minimumFractionDigits:2})}</strong>
      </div>`).join("") : `<p class="muted">No transactions yet.</p>`;
  }catch(e){
    localStorage.removeItem(tokenKey);
    show("login");
    $("loginMsg").textContent=e.message;
  }
}

function openTransfer(){show("transfer")}

async function transfer(){
  try{
    const data=await api("/api/transfers",{method:"POST",body:JSON.stringify({
      recipient_account:$("recipient").value,
      amount:Number($("amount").value),
      description:$("description").value || "Transfer"
    })});
    $("transferMsg").textContent=data.message;
    $("recipient").value=$("amount").value=$("description").value="";
    setTimeout(()=>show("dashboard"),700);
  }catch(e){$("transferMsg").textContent=e.message}
}

function logout(){
  localStorage.removeItem(tokenKey);
  show("login");
}

function escapeHtml(value){
  return String(value).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
}

if(localStorage.getItem(tokenKey)) show("dashboard");
else show("login");
