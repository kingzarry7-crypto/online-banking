from decimal import Decimal
from pydantic import BaseModel, EmailStr, Field


class RegisterIn(BaseModel):
    full_name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class VerifyOTPIn(BaseModel):
    email: EmailStr
    code: str = Field(min_length=6, max_length=6)


class TransferIn(BaseModel):
    recipient_account: str
    amount: Decimal = Field(gt=0, max_digits=18, decimal_places=2)
    description: str = Field(default="Transfer", max_length=200)
