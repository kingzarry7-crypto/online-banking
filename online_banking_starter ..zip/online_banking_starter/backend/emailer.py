import smtplib
from email.message import EmailMessage
from .database import settings


def send_otp_email(recipient: str, code: str) -> bool:
    # If SMTP is not configured, print the OTP during development.
    if not settings.SMTP_HOST:
        print(f"[DEV OTP] {recipient}: {code}")
        return True

    msg = EmailMessage()
    msg["Subject"] = "Your Online Banking verification code"
    msg["From"] = settings.SMTP_FROM or settings.SMTP_USERNAME
    msg["To"] = recipient
    msg.set_content(
        f"Your verification code is {code}. It expires in 10 minutes. "
        "If you did not request this code, ignore this message."
    )

    with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT) as smtp:
        smtp.starttls()
        smtp.login(settings.SMTP_USERNAME, settings.SMTP_PASSWORD)
        smtp.send_message(msg)

    return True
