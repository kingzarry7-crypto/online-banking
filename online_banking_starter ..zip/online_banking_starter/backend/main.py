from datetime import datetime, timedelta, timezone
from decimal import Decimal
import secrets

from fastapi import FastAPI, Depends, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import select, desc
from sqlalchemy.orm import Session

from .database import Base, engine, get_db, settings
from .models import User, Account, Transaction, OTP
from .schemas import RegisterIn, LoginIn, VerifyOTPIn, TransferIn
from .security import (
    hash_password, verify_password, create_access_token, decode_token,
    make_otp, hash_otp
)
from .emailer import send_otp_email

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Online Banking API", version="1.0.0")
app.mount("/static", StaticFiles(directory="frontend"), name="static")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Restrict to your frontend domain in production.
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def home():
    return FileResponse("frontend/index.html")


@app.get("/api/health")
def health():
    return {"status": "ok"}


def current_user(
    authorization: str | None = Header(default=None),
    db: Session = Depends(get_db),
):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Authentication required")
    try:
        user_id = int(decode_token(authorization[7:]))
    except Exception:
        raise HTTPException(401, "Invalid or expired session")
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(401, "User not found")
    return user


def create_account_number(db: Session) -> str:
    while True:
        number = "20" + "".join(str(secrets.randbelow(10)) for _ in range(10))
        if not db.scalar(select(Account).where(Account.account_number == number)):
            return number


@app.post("/api/auth/register")
def register(data: RegisterIn, db: Session = Depends(get_db)):
    email = data.email.lower().strip()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(409, "An account with this email already exists")

    user = User(
        full_name=data.full_name.strip(),
        email=email,
        password_hash=hash_password(data.password),
    )
    db.add(user)
    db.flush()

    db.add(Account(user_id=user.id, account_number=create_account_number(db), balance=Decimal("0.00")))

    code = make_otp()
    db.add(OTP(
        email=email,
        code_hash=hash_otp(code),
        purpose="verify",
        expires_at=datetime.now(timezone.utc) + timedelta(minutes=10),
    ))
    db.commit()

    send_otp_email(email, code)
    return {"message": "Registration created. Check your email for the OTP."}


@app.post("/api/auth/verify")
def verify(data: VerifyOTPIn, db: Session = Depends(get_db)):
    email = data.email.lower().strip()
    otp = db.scalar(
        select(OTP)
        .where(OTP.email == email, OTP.purpose == "verify", OTP.used == False)
        .order_by(desc(OTP.id))
    )
    if not otp or otp.expires_at < datetime.now(timezone.utc) or otp.code_hash != hash_otp(data.code):
        raise HTTPException(400, "Invalid or expired verification code")

    user = db.scalar(select(User).where(User.email == email))
    if not user:
        raise HTTPException(404, "User not found")

    otp.used = True
    user.is_verified = True
    db.commit()
    return {"message": "Account verified successfully"}


@app.post("/api/auth/login")
def login(data: LoginIn, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == data.email.lower().strip()))
    if not user or not verify_password(data.password, user.password_hash):
        raise HTTPException(401, "Invalid email or password")
    if not user.is_verified:
        raise HTTPException(403, "Verify your email before signing in")

    return {
        "access_token": create_access_token(str(user.id)),
        "token_type": "bearer",
    }


@app.get("/api/me")
def me(user: User = Depends(current_user), db: Session = Depends(get_db)):
    account = db.scalar(select(Account).where(Account.user_id == user.id))
    return {
        "full_name": user.full_name,
        "email": user.email,
        "account_number": account.account_number,
        "balance": str(account.balance),
    }


@app.get("/api/transactions")
def transactions(user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.scalars(
        select(Transaction)
        .where(Transaction.user_id == user.id)
        .order_by(desc(Transaction.created_at))
        .limit(50)
    ).all()
    return [
        {
            "id": x.id,
            "type": x.transaction_type,
            "amount": str(x.amount),
            "description": x.description,
            "status": x.status,
            "created_at": x.created_at.isoformat(),
        }
        for x in rows
    ]


@app.post("/api/transfers")
def transfer(data: TransferIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    sender = db.scalar(select(Account).where(Account.user_id == user.id))
    recipient = db.scalar(select(Account).where(Account.account_number == data.recipient_account))

    if not recipient:
        raise HTTPException(404, "Recipient account not found")
    if recipient.id == sender.id:
        raise HTTPException(400, "You cannot transfer to your own account")
    if sender.balance < data.amount:
        raise HTTPException(400, "Insufficient balance")

    # Demo ledger only. Add a real payment/banking provider after compliance and security review.
    sender.balance -= data.amount
    recipient.balance += data.amount

    db.add(Transaction(
        user_id=user.id,
        transaction_type="debit",
        amount=data.amount,
        description=data.description,
        status="completed",
    ))
    db.add(Transaction(
        user_id=recipient.user_id,
        transaction_type="credit",
        amount=data.amount,
        description=f"Transfer from {user.full_name}",
        status="completed",
    ))
    db.commit()

    return {"message": "Transfer completed", "amount": str(data.amount)}


@app.get("/api/admin/users")
def admin_users(
    x_admin_email: str | None = Header(default=None),
    x_admin_password: str | None = Header(default=None),
    db: Session = Depends(get_db),
):
    if x_admin_email != settings.ADMIN_EMAIL or x_admin_password != settings.ADMIN_PASSWORD:
        raise HTTPException(401, "Admin authentication failed")

    users = db.scalars(select(User).order_by(desc(User.id))).all()
    return [
        {
            "id": u.id,
            "name": u.full_name,
            "email": u.email,
            "verified": u.is_verified,
            "account": u.account.account_number if u.account else None,
            "balance": str(u.account.balance) if u.account else "0.00",
        }
        for u in users
    ]
